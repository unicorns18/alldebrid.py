from .alldebrid import AllDebrid

__all__ = ['AllDebrid']
